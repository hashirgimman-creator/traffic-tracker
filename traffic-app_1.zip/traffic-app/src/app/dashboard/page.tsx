'use client'
import { useEffect, useState, useCallback } from 'react'
import { createClient } from '@/lib/supabase'
import { useRouter } from 'next/navigation'

type Violation = {
  id: string
  plate: string
  driver: string
  vehicle: string
  type: string
  location: string
  severity: string
  notes: string
  created_at: string
}

const TYPE_COLORS: Record<string, string> = {
  'Red light': 'bg-red-100 text-red-700',
  'Speed violation': 'bg-amber-100 text-amber-700',
  'Illegal turn': 'bg-yellow-100 text-yellow-800',
  'Stop sign': 'bg-blue-100 text-blue-700',
}
const SEV_COLORS: Record<string, string> = {
  'Critical': 'bg-red-100 text-red-700',
  'High': 'bg-amber-100 text-amber-700',
  'Medium': 'bg-blue-100 text-blue-700',
}

const EMPTY_FORM = { plate: '', driver: '', vehicle: '', type: 'Red light', location: '', severity: 'Medium', notes: '' }

export default function Dashboard() {
  const [violations, setViolations] = useState<Violation[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState(EMPTY_FORM)
  const [saving, setSaving] = useState(false)
  const [search, setSearch] = useState('')
  const [filterType, setFilterType] = useState('')
  const [filterSev, setFilterSev] = useState('')
  const [userEmail, setUserEmail] = useState('')
  const router = useRouter()
  const supabase = createClient()

  const fetchViolations = useCallback(async () => {
    const { data } = await supabase.from('violations').select('*').order('created_at', { ascending: false })
    setViolations(data || [])
    setLoading(false)
  }, [supabase])

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) { router.push('/auth'); return }
      setUserEmail(session.user.email || '')
      fetchViolations()
    })
  }, [router, supabase, fetchViolations])

  async function signOut() {
    await supabase.auth.signOut()
    router.push('/auth')
  }

  async function saveViolation() {
    if (!form.plate.trim() || !form.location.trim()) return alert('Plate and location are required.')
    setSaving(true)
    await supabase.from('violations').insert([{ ...form, plate: form.plate.toUpperCase().trim() }])
    setForm(EMPTY_FORM)
    setShowModal(false)
    setSaving(false)
    fetchViolations()
  }

  async function deleteViolation(id: string) {
    if (!confirm('Delete this record?')) return
    await supabase.from('violations').delete().eq('id', id)
    fetchViolations()
  }

  const plateCounts = violations.reduce<Record<string, number>>((acc, v) => {
    acc[v.plate] = (acc[v.plate] || 0) + 1; return acc
  }, {})

  const filtered = violations.filter(v => {
    const q = search.toLowerCase()
    const mq = !q || v.plate.toLowerCase().includes(q) || v.driver?.toLowerCase().includes(q) || v.location?.toLowerCase().includes(q)
    return mq && (!filterType || v.type === filterType) && (!filterSev || v.severity === filterSev)
  })

  const topOffender = Object.entries(plateCounts).sort((a, b) => b[1] - a[1])[0]
  const criticalCount = violations.filter(v => v.severity === 'Critical').length
  const uniquePlates = Object.keys(plateCounts).length

  function formatTime(iso: string) {
    return new Date(iso).toLocaleString('en-PK', { dateStyle: 'short', timeStyle: 'short' })
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-2xl">🚦</span>
            <div>
              <h1 className="text-lg font-semibold text-gray-900">Traffic Violation Tracker</h1>
              <p className="text-xs text-gray-400">Live monitoring dashboard</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-500 hidden sm:block">{userEmail}</span>
            <button onClick={signOut} className="text-sm text-gray-500 hover:text-gray-800 border border-gray-300 rounded-lg px-3 py-1.5">Sign out</button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total violations', value: violations.length, color: 'text-gray-900' },
            { label: 'Critical', value: criticalCount, color: 'text-red-600' },
            { label: 'Unique vehicles', value: uniquePlates, color: 'text-amber-600' },
            { label: 'This session', value: violations.length, color: 'text-green-600' },
          ].map(s => (
            <div key={s.label} className="bg-white rounded-xl border border-gray-200 p-4">
              <p className="text-xs text-gray-500 mb-1">{s.label}</p>
              <p className={`text-2xl font-semibold ${s.color}`}>{s.value}</p>
            </div>
          ))}
        </div>

        {/* Top offender banner */}
        {topOffender && topOffender[1] >= 2 && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-6 flex items-center gap-4">
            <span className="text-2xl">⚠️</span>
            <div>
              <p className="text-xs font-medium text-red-600 mb-0.5">Top repeat offender</p>
              <p className="font-mono font-semibold text-gray-900 text-lg">{topOffender[0]}</p>
              <p className="text-sm text-red-600">{topOffender[1]} violations on record</p>
            </div>
          </div>
        )}

        {/* Controls */}
        <div className="flex flex-wrap gap-3 mb-5 items-center">
          <input
            type="text" value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search plate, driver, location…"
            className="flex-1 min-w-[200px] border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <select value={filterType} onChange={e => setFilterType(e.target.value)}
            className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none">
            <option value="">All types</option>
            {['Red light','Speed violation','Illegal turn','Stop sign'].map(t => <option key={t}>{t}</option>)}
          </select>
          <select value={filterSev} onChange={e => setFilterSev(e.target.value)}
            className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none">
            <option value="">All severity</option>
            {['Critical','High','Medium'].map(s => <option key={s}>{s}</option>)}
          </select>
          <button onClick={() => setShowModal(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 text-sm font-medium flex items-center gap-2">
            + Log violation
          </button>
        </div>

        {/* Table */}
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          {loading ? (
            <p className="text-center text-gray-400 py-12 text-sm">Loading records…</p>
          ) : filtered.length === 0 ? (
            <p className="text-center text-gray-400 py-12 text-sm">No violations found. Log the first one!</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-200 bg-gray-50">
                    {['Plate','Driver','Type','Location','Severity','Time',''].map(h => (
                      <th key={h} className="text-left text-xs font-medium text-gray-500 px-4 py-3">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map(v => (
                    <tr key={v.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="px-4 py-3">
                        <span className="font-mono font-medium bg-gray-100 border border-gray-300 rounded px-2 py-0.5 text-xs">{v.plate}</span>
                        {plateCounts[v.plate] > 1 && <span className="ml-1 text-xs text-red-500">×{plateCounts[v.plate]}</span>}
                      </td>
                      <td className="px-4 py-3 text-gray-600">{v.driver || '—'}</td>
                      <td className="px-4 py-3">
                        <span className={`text-xs font-medium px-2 py-1 rounded-full ${TYPE_COLORS[v.type] || 'bg-gray-100 text-gray-600'}`}>{v.type}</span>
                      </td>
                      <td className="px-4 py-3 text-gray-600 text-xs max-w-[140px] truncate">{v.location}</td>
                      <td className="px-4 py-3">
                        <span className={`text-xs font-medium px-2 py-1 rounded-full ${SEV_COLORS[v.severity] || ''}`}>{v.severity}</span>
                      </td>
                      <td className="px-4 py-3 text-gray-400 text-xs whitespace-nowrap">{formatTime(v.created_at)}</td>
                      <td className="px-4 py-3">
                        <button onClick={() => deleteViolation(v.id)}
                          className="text-gray-400 hover:text-red-500 transition text-xs border border-gray-200 hover:border-red-300 rounded px-2 py-1">
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={e => { if (e.target === e.currentTarget) setShowModal(false) }}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-xl">
            <h2 className="text-lg font-semibold text-gray-900 mb-5">Log new violation</h2>
            <div className="space-y-4">
              {[
                { label: 'License plate *', key: 'plate', placeholder: 'e.g. LHR-4421', upper: true },
                { label: 'Driver name', key: 'driver', placeholder: 'Full name (optional)' },
                { label: 'Vehicle description', key: 'vehicle', placeholder: 'e.g. Honda Civic, white' },
                { label: 'Intersection / Location *', key: 'location', placeholder: 'e.g. Mall Rd & Jail Rd' },
              ].map(f => (
                <div key={f.key}>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{f.label}</label>
                  <input
                    value={(form as any)[f.key]}
                    onChange={e => setForm(p => ({ ...p, [f.key]: f.upper ? e.target.value.toUpperCase() : e.target.value }))}
                    placeholder={f.placeholder}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              ))}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Violation type</label>
                  <select value={form.type} onChange={e => setForm(p => ({ ...p, type: e.target.value }))}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none">
                    {['Red light','Speed violation','Illegal turn','Stop sign'].map(t => <option key={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Severity</label>
                  <select value={form.severity} onChange={e => setForm(p => ({ ...p, severity: e.target.value }))}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none">
                    {['Medium','High','Critical'].map(s => <option key={s}>{s}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
                <textarea value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))}
                  placeholder="Additional details…"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none h-20 resize-none" />
              </div>
            </div>
            <div className="flex gap-3 mt-6 justify-end">
              <button onClick={() => setShowModal(false)}
                className="border border-gray-300 rounded-lg px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">Cancel</button>
              <button onClick={saveViolation} disabled={saving}
                className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-5 py-2 text-sm font-medium disabled:opacity-50">
                {saving ? 'Saving…' : 'Save record'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
